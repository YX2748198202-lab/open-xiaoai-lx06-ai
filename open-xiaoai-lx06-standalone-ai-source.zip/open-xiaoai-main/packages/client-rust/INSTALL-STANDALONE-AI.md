# LX06 Standalone AI 安装包

构建产物包含：

- `standalone-ai`：运行于 LX06 的 ARMv7 程序
- `install-standalone-ai.sh`：安装并注册 `/data/init.sh` 自启动
- `ai.conf.example`：配置示例

安装前先把 `standalone-ai` 放到 `/data/open-xiaoai/standalone-ai` 并加执行权限，再运行 `install-standalone-ai.sh`。
