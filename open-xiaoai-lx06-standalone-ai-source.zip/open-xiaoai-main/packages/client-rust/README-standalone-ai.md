# LX06 Standalone AI

这是基于 `open-xiaoai` Rust Client 的音箱侧独立 AI 方案。

## 工作方式

- 使用 LX06 原生 XiaoAI 的唤醒和语音识别。
- `standalone-ai` 监控 LX06 固件实际写入的 `/tmp/mico_aivs_lab/event.log`。
- 从 LX06 的 `event.log` 和 `/tmp/log/messages` 读取原生 ASR 结果；当前固件使用 `speech_recognizer.asr=... nlp=true` 日志格式。
- 智能家居/设备控制类指令交给原生 XiaoAI 独占处理，避免原小爱和远程模型重复执行或抢答。
- 普通问答先抑制原生 XiaoAI，再使用 `curl` 调用 OpenAI-compatible `chat/completions` API。
- Mimo/API 请求失败时，自动通过 LX06 原生 `mibrain.ai_service` 回退给小爱；连续失败后进入5分钟冷却，后续请求直接交给原生 XiaoAI。
- 使用 LX06 的 `mibrain.text_to_speech` ubus 接口把 AI 文本转换并播放为语音。
- 对话历史保存在进程内存中，设备重启后清空。

## 配置

文件：`/data/open-xiaoai/ai.conf`

```ini
BASE_URL=https://api.openai.com/v1
API_KEY=sk-xxxxxxxx
MODEL=gpt-4.1-mini
SYSTEM_PROMPT=你是一个智能语音助手，请直接、自然地回答用户的问题。
HISTORY_MAX_LENGTH=10
MAX_RESPONSE_CHARS=1200
REQUEST_TIMEOUT_SECONDS=25
ABORT_DELAY_MS=400
TTS_TIMEOUT_SECONDS=120
```

`BASE_URL` 应指向 OpenAI-compatible API 的基础路径，程序自动补 `/chat/completions`。也可以直接填写完整的 `/chat/completions` 地址。

## 限制

此方案依赖 LX06 当前固件中的原生 XiaoAI 语音识别和 TTS 能力。它不是在 LX06 本地运行 ASR/LLM/TTS 模型。

API 厂商必须提供与 OpenAI Chat Completions 兼容的接口；项目没有为 Gemini 原生 Live API、Claude 原生 API 等非兼容协议增加独立适配器。
