# LX06 Standalone AI

音箱本机运行；电脑/手机仅用于开发维护，不需要常驻服务器。

## 路由与限制
- LX06 1.94.13 实測从 `/tmp/log/messages` 的 `speech_recognizer.asr=..., .final=..., nlp=true` 读取文本。`nlp=true` 是实测交接标记，不等于 ASR final。
- `/tmp/mico_aivs_lab/instruction.log` 保留用于其他固件的 JSON 兼容；本机不存在时不会报错。`event.log` 是上传事件，不能当成最终识别文本源。
- 常见智能家居、播放、音量、闹钟指令留给原小爱，本程序不重复调用控制操作。
- 普通知识问答重启原小爱语音服务后交给兼容 API。这是尽力抑制，不是系统级静音：已排队的原生语音仍有竞争窗口。路由是本地规则，不是完美意图识别。
- API HTTP/网络/JSON 错误时，本次通过 `mibrain.ai_service` 尝试降级，携带 `nlp_execute=0`；进入300秒冷却，后续请求直接留给小爱，期满尝试恢复。余额不足可能表现为402/429或业务错误，不只一种状态。
- 请求期间又收到新问题/控制指令时，旧 AI 回答不再播报。已经开始的TTS未实现逐句打断。
- 使用 `mibrain.text_to_speech`，严格解析 JSON code。accepted 仅代表接口接受，不表示音频已播放完。
- 仍依赖小米原生云端 ASR/TTS；不是离线大模型。保留多轮上下文，默认10轮、单回复1200字符上限。

## 配置
SSH 编辑 `/data/open-xiaoai/ai.conf`，具体模板见 `standalone-ai.conf.example`。
`BASE_URL` 自动补 `/chat/completions`；兼容完整端点。保留自己的 API_KEY 和 MODEL。
默认 API 请求25秒、接管后等待400毫秒，Prompt按问题复杂度调整长度。HTTP/1.1是兼容设置，不宣称它必然降低推理时延。

## 管理与验证
修改配置后重启 standalone-ai。`--check-config` 只输出配置概要，不输出 Key。
`--ask '只回复测试成功'` 是一次性完整处理测试，会短暂重启小爱语音服务，应先停止常驻进程，测试后恢复。
`--config PATH` 可指定隔离测试配置，不要用真实智能家居指令测降级。
日志有 takeover_ms/api_ms/tts_ms/total_ms；不包含原始ASR耗时或播放全长。
日志监控支持文件轮转/截断/半行；curl凭据通过stdin传递，不写临时文件、不出现在进程参数。

## 安装与回滚
文件全部位于 `/data`。本机已读取确认 `/etc/rc.local` 会调用 `/data/init.sh`。
安装前备份，配置不会覆盖；不要修改只读rootfs或固件分区。
重启验收、实际音频听感与复杂路由仍需实机确认，CI成功不代表这些已完成。
