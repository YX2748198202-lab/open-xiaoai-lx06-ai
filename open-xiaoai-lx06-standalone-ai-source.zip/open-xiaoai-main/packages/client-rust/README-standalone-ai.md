# LX06 Standalone AI

这是基于 `open-xiaoai` Rust Client 的音箱侧独立 AI 方案。

## 工作方式

- 使用 LX06 原生 XiaoAI 的唤醒和语音识别。
- `standalone-ai` 监控 LX06 固件实际写入的 `/tmp/mico_aivs_lab/event.log`。
- 收到 `SpeechRecognizer/RecognizeResult` 的最终识别文本后，立即重启原 XiaoAI 服务，避免原服务同时回答。
- 音箱直接使用 `curl` 调用 OpenAI-compatible `chat/completions` API。
- 使用 LX06 的 `mibrain.text_to_speech` ubus 接口把 AI 文本转换并播放为语音。
- 对话历史保存在进程内存中，设备重启后清空。

## 配置

文件：`/data/open-xiaoai/ai.conf`

```ini
BASE_URL=https://api.openai.com/v1
API_KEY=sk-xxxxxxxx
MODEL=gpt-4.1-mini
SYSTEM_PROMPT=你是一个智能语音助手，请直接、自然地回答用户的问题。
HISTORY_MAX_LENGTH=10
MAX_RESPONSE_CHARS=1200
REQUEST_TIMEOUT_SECONDS=90
ABORT_DELAY_MS=2000
TTS_TIMEOUT_SECONDS=120
```

`BASE_URL` 应指向 OpenAI-compatible API 的基础路径，程序自动补 `/chat/completions`。也可以直接填写完整的 `/chat/completions` 地址。

## 限制

此方案依赖 LX06 当前固件中的原生 XiaoAI 语音识别和 TTS 能力。它不是在 LX06 本地运行 ASR/LLM/TTS 模型。

API 厂商必须提供与 OpenAI Chat Completions 兼容的接口；项目没有为 Gemini 原生 Live API、Claude 原生 API 等非兼容协议增加独立适配器。
