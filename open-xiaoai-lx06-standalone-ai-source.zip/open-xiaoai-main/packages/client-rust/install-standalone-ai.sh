#!/bin/sh
set -eu
BASE_DIR=/data/open-xiaoai
BIN="$BASE_DIR/standalone-ai"
CONF="$BASE_DIR/ai.conf"
START="$BASE_DIR/ai-start.sh"
INIT=/data/init.sh
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SOURCE_BIN="$SCRIPT_DIR/standalone-ai"

backup_if_exists() {
  target=$1
  if [ -e "$target" ]; then
    backup="$target.bak"
    if [ -e "$backup" ]; then
      backup="$target.bak.$$"
    fi
    cp -p "$target" "$backup"
    echo "Backed up $target to $backup"
  fi
}

mkdir -p "$BASE_DIR"
if [ ! -f "$SOURCE_BIN" ]; then
  echo "standalone-ai binary not found next to installer: $SOURCE_BIN" >&2
  exit 1
fi
backup_if_exists "$BIN"
cp "$SOURCE_BIN" "$BIN.new"
chmod 755 "$BIN.new"
mv -f "$BIN.new" "$BIN"

if [ ! -f "$CONF" ]; then
  cat > "$CONF" <<'CFG'
BASE_URL=https://api.openai.com/v1
API_KEY=CHANGE_ME
MODEL=gpt-4.1-mini
SYSTEM_PROMPT=你是通过独立大模型客户端接入小米小爱音箱 Pro 的中文语音助手，不是原生小爱服务。回答由音箱朗读。根据问题复杂度调整长度：简单问题直接回答，解释、分析、教程、故事和详细比较可以充分展开，不为简短省略关键内容。语言自然清晰，默认不使用Markdown、标题、表格、项目符号、代码块、网址或Emoji。不要重复问题。你的实际模型标识由运行时提供；被问及身份时如实说明，不冒充原生小爱。你没有智能家居、播放音乐、设置闹钟、实时天气或联网搜索工具，不要声称能执行或已执行这些操作；设备控制由原生小爱另行处理。涉及最新信息或不确定事实要说明限制，不编造更新日期和结果。正常回答不主动解释后台技术，用户询问时可以如实解释。
HISTORY_MAX_LENGTH=10
MAX_RESPONSE_CHARS=1200
REQUEST_TIMEOUT_SECONDS=25
ABORT_DELAY_MS=400
TTS_TIMEOUT_SECONDS=120
CFG
  chmod 600 "$CONF"
  echo "Created $CONF"
fi

backup_if_exists "$START"
cat > "$START" <<'SH'
#!/bin/sh
BASE_DIR=/data/open-xiaoai
BIN="$BASE_DIR/standalone-ai"
LOG=/tmp/open-xiaoai-ai.log
[ -x "$BIN" ] || exit 0

if pidof standalone-ai >/dev/null 2>&1; then
  exit 0
fi
"$BIN" >> "$LOG" 2>&1 &
SH
chmod 755 "$START"

if [ ! -f "$INIT" ]; then
  printf '%s\n' '#!/bin/sh' > "$INIT"
  chmod 755 "$INIT"
else
  backup_if_exists "$INIT"
fi
if ! grep -Fq "$START" "$INIT" 2>/dev/null; then
  printf '\n# open-xiaoai standalone AI\n[ -x "%s" ] && "%s"\n' "$START" "$START" >> "$INIT"
fi

killall standalone-ai 2>/dev/null || true
sleep 1
"$START"

echo "Standalone AI installed and started."
echo "Edit: $CONF"

