#!/bin/sh
set -eu
BASE_DIR=/data/open-xiaoai
BIN="$BASE_DIR/standalone-ai"
CONF="$BASE_DIR/ai.conf"
START="$BASE_DIR/ai-start.sh"
INIT=/data/init.sh
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SOURCE_BIN="$SCRIPT_DIR/standalone-ai"

backup_if_exists() {
  target=$1
  if [ -e "$target" ]; then
    backup="$target.bak"
    if [ -e "$backup" ]; then
      backup="$target.bak.$$"
    fi
    cp -p "$target" "$backup"
    echo "Backed up $target to $backup"
  fi
}

mkdir -p "$BASE_DIR"
if [ ! -f "$SOURCE_BIN" ]; then
  echo "standalone-ai binary not found next to installer: $SOURCE_BIN" >&2
  exit 1
fi
backup_if_exists "$BIN"
cp "$SOURCE_BIN" "$BIN"
chmod 755 "$BIN"

if [ ! -f "$CONF" ]; then
  cat > "$CONF" <<'CFG'
BASE_URL=https://api.openai.com/v1
API_KEY=CHANGE_ME
MODEL=gpt-4.1-mini
SYSTEM_PROMPT=你是运行在小米小爱音箱 Pro 上的中文语音助手。你的回答会由音箱直接朗读。根据问题复杂度调整长度：简单问题直接回答；解释、分析、教程、故事和详细比较可以适当展开，不要为了简短而省略关键内容。回答要自然、清晰、适合语音朗读。默认不要使用Markdown、标题、表格、项目符号、代码块、网址或Emoji，除非用户明确要求。不要重复用户的问题。不要声称自己已经控制灯光、空调或其他设备；如果没有可用控制工具，不要编造执行结果。不确定时明确说明。不要提及API、后台程序或内部实现。
HISTORY_MAX_LENGTH=10
MAX_RESPONSE_CHARS=1200
REQUEST_TIMEOUT_SECONDS=25
ABORT_DELAY_MS=400
TTS_TIMEOUT_SECONDS=120
CFG
  chmod 600 "$CONF"
  echo "Created $CONF"
fi

backup_if_exists "$START"
cat > "$START" <<'SH'
#!/bin/sh
BASE_DIR=/data/open-xiaoai
BIN="$BASE_DIR/standalone-ai"
LOG=/tmp/open-xiaoai-ai.log
[ -x "$BIN" ] || exit 0

if ps | grep "[s]tandalone-ai" >/dev/null 2>&1; then
  exit 0
fi
"$BIN" >> "$LOG" 2>&1 &
SH
chmod 755 "$START"

if [ ! -f "$INIT" ]; then
  printf '%s\n' '#!/bin/sh' > "$INIT"
  chmod 755 "$INIT"
else
  backup_if_exists "$INIT"
fi
if ! grep -Fq "$START" "$INIT" 2>/dev/null; then
  printf '\n# open-xiaoai standalone AI\n[ -x "%s" ] && "%s"\n' "$START" "$START" >> "$INIT"
fi

pkill -f "/data/open-xiaoai/standalone-ai" 2>/dev/null || true
"$START"

echo "Standalone AI installed and started."
echo "Edit: $CONF"

