#!/bin/sh
set -eu

BASE_DIR=/data/open-xiaoai
BIN="$BASE_DIR/standalone-ai"
CONF="$BASE_DIR/ai.conf"
START="$BASE_DIR/ai-start.sh"
INIT=/data/init.sh

mkdir -p "$BASE_DIR"

if [ ! -x "$BIN" ]; then
  echo "standalone-ai binary not found: $BIN" >&2
  exit 1
fi

if [ ! -f "$CONF" ]; then
  cat > "$CONF" <<'CFG'
BASE_URL=https://api.openai.com/v1
API_KEY=CHANGE_ME
MODEL=gpt-4.1-mini
SYSTEM_PROMPT=你是一个智能语音助手，请直接、自然地回答用户的问题。
HISTORY_MAX_LENGTH=10
MAX_RESPONSE_CHARS=1200
REQUEST_TIMEOUT_SECONDS=90
ABORT_DELAY_MS=2000
TTS_TIMEOUT_SECONDS=120
CFG
  chmod 600 "$CONF"
  echo "Created $CONF"
fi

cat > "$START" <<'SH'
#!/bin/sh
BASE_DIR=/data/open-xiaoai
BIN="$BASE_DIR/standalone-ai"
LOG=/tmp/open-xiaoai-ai.log

[ -x "$BIN" ] || exit 0

if ps | grep "[s]tandalone-ai" >/dev/null 2>&1; then
  exit 0
fi

"$BIN" >> "$LOG" 2>&1 &
SH
chmod 755 "$START"

if [ ! -f "$INIT" ]; then
  printf '%s\n' '#!/bin/sh' > "$INIT"
  chmod 755 "$INIT"
fi

if ! grep -Fq "$START" "$INIT" 2>/dev/null; then
  printf '\n# open-xiaoai standalone AI\n[ -x "%s" ] && "%s"\n' "$START" "$START" >> "$INIT"
fi

pkill -f "/data/open-xiaoai/standalone-ai" 2>/dev/null || true
"$START"

echo "Standalone AI installed and started."
echo "Edit: $CONF"
